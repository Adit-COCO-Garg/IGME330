<?php 
    phpinfo(); 
?>