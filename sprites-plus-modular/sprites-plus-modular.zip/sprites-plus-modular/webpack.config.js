module.exports = {
    entry: './src/loader.js',
    output: {
        filename: './bundle.js'
    }
};