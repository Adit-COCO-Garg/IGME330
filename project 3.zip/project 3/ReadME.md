# True random number generator

## Proposal
The project aims to make truly random numbers accessible.
The purpose of pursuit of this project is two fold: learn quantum computing and create tools that provide an impact on the community of developers. This pursuit will hopefully inspire/ entice more people to get involved with quantum computing and push forth as a community of developers.

## Possible use cases 
- True classical random encryption
- General random number requirement: games, software, etc.

## Tools 
- I plan to use one of the following frameworks: 
	- [Qiskit](https://qiskit.org/ "IBM Qiskit")
	- [Q#](https://docs.microsoft.com/en-us/quantum/ "Microsoft Q# documentation")
	- [Cirq](https://github.com/quantumlib/Cirq "Open source Quantum framework")
  
These frameworks will tie in with some math analytical api (graphing, etc), Firebase, and may feature it's own API.
- Vue
- HTML, SCSS, JS,
- I might use NoSQL, MySQL (MyQLIi if needed), or any other flavor depending on the implementation
- PHP or node 
 
 ![Mockup](mockup.png)


## ideas -  for  Project 3
trading bot
buy - sell suggester 

text to speech event generator - poc

algorithm visualizaer - use maps api to find shortest route and own api for some algo

based on your profile suggests - anime, movies, shows, events etc

tinder for food but you add in ingredients and get suggestions

eh > a portfolio backend and front end

 valid - covid 19 app ->> tracks cases and heatmaps

clarifai - food suggestor based on mood

a text to speech youtube

quantum random number generator

[https://github.com/public-apis/public-apis#url-shorteners](https://github.com/public-apis/public-apis#url-shorteners)


[https://github.com/n0shake/Public-APIs#check-in](https://github.com/n0shake/Public-APIs#check-in)




